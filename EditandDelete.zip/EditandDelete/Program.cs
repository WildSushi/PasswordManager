﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using DB;


namespace Edit_Delete_clickable_list
{
    public static class Globals
    {
        public static int intGlobalID;
        
    }
    static class Program
    {

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            SQLiteDB.DatabasePath = "credential.db";
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            Application.Run(new frmEdit());
            Application.Run(new frmDelete());
        }
        static public void AddtoDB(string[] txtbxs)
        {
            
            
            SQLiteDB db = SQLiteDB.GetInstance;
          
            db.NonSelectQuery("INSERT INTO credentials (Name, Username, Password, Website, Notes) VALUES ('" + txtbxs[0] + "', '" + txtbxs[1] + "', '" + txtbxs[2] + "', '" + txtbxs[3] + "', '" + txtbxs[4] + "')");

            db.CloseConnection();
        }
        static public void UpdateDB(string[] txtbxs)
        {

            
            SQLiteDB db = SQLiteDB.GetInstance;

            db.NonSelectQuery("UPDATE credentials SET Name = '" + txtbxs[0] + "', Username = '" + txtbxs[1] + "', Password = '" + txtbxs[2] + "', Website = '" + txtbxs[3] + "', Notes = '" + txtbxs[4] + "' WHERE ID = " + Globals.intGlobalID + "");
            

            db.CloseConnection();
        }
        static public void DeletefromDB()
        {
            SQLiteDB db = SQLiteDB.GetInstance;

            db.NonSelectQuery("DELETE FROM credentials WHERE ID = " + Globals.intGlobalID + "");

            db.CloseConnection();
        }
    }
}
   
