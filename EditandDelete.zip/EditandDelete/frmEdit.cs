﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using DB;

namespace Edit_Delete_clickable_list
{
    public partial class frmEdit : Form
    {
        public frmEdit()
        {
            InitializeComponent();
            pullindata();
        }

        private void pullindata()
        { 
            SQLiteDB db = SQLiteDB.GetInstance;

            DataSet ds = db.SelectQuery("SELECT * FROM credentials WHERE ID = " + Globals.intGlobalID + ";", "credentials");

            DataTable dt = ds.Tables[0];

            string[] cred = dt.Rows[0].ItemArray.Select(x => x.ToString()).ToArray();
          
            txtEdit_name.Text = cred[1];
            txtEdit_user.Text = cred[2];
            txtEdit_pass.Text = cred[3];
            txtEdit_website.Text = cred[4];
            txtEdit_notes.Text = cred[5];

            db.CloseConnection();
        }
        
        private void btnEdit_save_Click(object sender, EventArgs e)
        {
            string[] txtbxs = new string[5];

            txtbxs[0] = txtEdit_name.Text;
            txtbxs[1] = txtEdit_user.Text;
            txtbxs[2] = txtEdit_pass.Text;
            txtbxs[3] = txtEdit_website.Text;
            txtbxs[4] = txtEdit_notes.Text;

            Program.UpdateDB(txtbxs);

        }
    }
}
        