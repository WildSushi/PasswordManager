﻿namespace Edit_Delete_clickable_list
{
    partial class frmEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEdit_save = new System.Windows.Forms.Button();
            this.txtEdit_name = new System.Windows.Forms.TextBox();
            this.txtEdit_user = new System.Windows.Forms.TextBox();
            this.txtEdit_pass = new System.Windows.Forms.TextBox();
            this.txtEdit_notes = new System.Windows.Forms.TextBox();
            this.txtEdit_website = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnEdit_save
            // 
            this.btnEdit_save.Location = new System.Drawing.Point(206, 447);
            this.btnEdit_save.Name = "btnEdit_save";
            this.btnEdit_save.Size = new System.Drawing.Size(75, 23);
            this.btnEdit_save.TabIndex = 0;
            this.btnEdit_save.Text = "SAVE";
            this.btnEdit_save.UseVisualStyleBackColor = true;
            this.btnEdit_save.Click += new System.EventHandler(this.btnEdit_save_Click);
            // 
            // txtEdit_name
            // 
            this.txtEdit_name.Location = new System.Drawing.Point(438, 69);
            this.txtEdit_name.Name = "txtEdit_name";
            this.txtEdit_name.Size = new System.Drawing.Size(100, 20);
            this.txtEdit_name.TabIndex = 1;
            // 
            // txtEdit_user
            // 
            this.txtEdit_user.Location = new System.Drawing.Point(438, 126);
            this.txtEdit_user.Name = "txtEdit_user";
            this.txtEdit_user.Size = new System.Drawing.Size(100, 20);
            this.txtEdit_user.TabIndex = 2;
            // 
            // txtEdit_pass
            // 
            this.txtEdit_pass.Location = new System.Drawing.Point(438, 189);
            this.txtEdit_pass.Name = "txtEdit_pass";
            this.txtEdit_pass.Size = new System.Drawing.Size(100, 20);
            this.txtEdit_pass.TabIndex = 3;
            // 
            // txtEdit_notes
            // 
            this.txtEdit_notes.Location = new System.Drawing.Point(438, 313);
            this.txtEdit_notes.Name = "txtEdit_notes";
            this.txtEdit_notes.Size = new System.Drawing.Size(100, 20);
            this.txtEdit_notes.TabIndex = 5;
            // 
            // txtEdit_website
            // 
            this.txtEdit_website.Location = new System.Drawing.Point(438, 250);
            this.txtEdit_website.Name = "txtEdit_website";
            this.txtEdit_website.Size = new System.Drawing.Size(100, 20);
            this.txtEdit_website.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Username";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 259);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "website";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(47, 319);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "notes";
            // 
            // frmEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 503);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtEdit_notes);
            this.Controls.Add(this.txtEdit_website);
            this.Controls.Add(this.txtEdit_pass);
            this.Controls.Add(this.txtEdit_user);
            this.Controls.Add(this.txtEdit_name);
            this.Controls.Add(this.btnEdit_save);
            this.Name = "frmEdit";
            this.Text = "Edit Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEdit_save;
        private System.Windows.Forms.TextBox txtEdit_name;
        private System.Windows.Forms.TextBox txtEdit_user;
        private System.Windows.Forms.TextBox txtEdit_pass;
        private System.Windows.Forms.TextBox txtEdit_notes;
        private System.Windows.Forms.TextBox txtEdit_website;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}